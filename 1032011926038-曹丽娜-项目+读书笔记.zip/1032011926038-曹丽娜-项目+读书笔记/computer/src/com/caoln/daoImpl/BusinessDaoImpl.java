package com.caoln.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.caoln.bean.Business;
import com.caoln.dao.BusinessDao;
import com.caoln.jdbc.ConnectionPool;


/** 
 * 类说明 
 */
public class BusinessDaoImpl implements BusinessDao {

	@Override
	public Business businessLogin(String name, String password) {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		Business business = new Business();
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql="SELECT * FROM BUSINESS WHERE NAME=? AND PASSWORD=? AND STATE='1'";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			ps.setString(1,name);
			ps.setString(2,password);
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString("name"));
				business.setId(rs.getInt("id"));
				business.setName(rs.getString("name"));
				business.setTel(rs.getString("tel"));
				business.setEmail(rs.getString("email"));
				business.setShopname(rs.getString("shopname"));
				business.setSimple(rs.getString("simple"));
				business.setAddress(rs.getString("address"));
				business.setTime(rs.getString("time"));
				business.setQq(rs.getString("qq"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return business;
	}

	@Override
	public int businessRegister(Business business) {
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "INSERT INTO BUSINESS VALUES(null,?,?,?,?,?,?,?,?,?,DEFAULT)";
			ps = connection.prepareStatement(sql);
			ps.setString(1, business.getName());
			ps.setString(2, business.getPassword());
			ps.setString(3, business.getTel());
			ps.setString(4, business.getQq());
			ps.setString(5, business.getEmail());
			ps.setString(6, business.getShopname());
			ps.setString(7, business.getAddress());
			ps.setString(8, business.getTime());
			ps.setString(9, business.getSimple());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public List<String> getShopNameList() {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		List<String> shopName = new ArrayList<String>();
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql="SELECT SHOPNAME FROM BUSINESS ";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString(1));
				shopName.add(rs.getString(1));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return shopName;
	}

	@Override
	public List<Business> getBusinessInfoByName(String name) {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		
		List<Business> list = new ArrayList<>();
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql="SELECT A.* FROM BUSINESS A ,PRODUCT B WHERE A.ID=B.BUSINESS AND A.STATE='1' AND A.SHOPNAME like ? or A.simple like ? OR B.TITLE LIKE ? group by A.NAME";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			ps.setString(1,"%"+name+"%");
			ps.setString(2,"%"+name+"%");
			ps.setString(3,"%"+name+"%");
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				Business business = new Business();
				System.out.println(rs.getString("name"));
				business.setId(rs.getInt("id"));
				business.setName(rs.getString("name"));
				business.setTel(rs.getString("tel"));
				business.setQq(rs.getString("qq"));
				business.setEmail(rs.getString("email"));
				business.setShopname(rs.getString("shopname"));
				business.setAddress(rs.getString("address"));
				business.setTime(rs.getString("time"));
				business.setSimple(rs.getString("simple"));
				list.add(business);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return list;
		
	}

	@Override
	public int changePassword(int id, String password) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE BUSINESS SET PASSWORD =? WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, password);
			ps.setInt(2, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int changeBusinessInfo(Business business) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE BUSINESS SET TEL=? , QQ=? , EMAIL=? , ADDRESS=? , TIME=? , SIMPLE=? WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, business.getTel());
			ps.setString(2, business.getQq());
			ps.setString(3, business.getEmail());
			ps.setString(4, business.getAddress());
			ps.setString(5, business.getTime());
			ps.setString(6, business.getSimple());
			ps.setInt(7, business.getId());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public List<Business> getBusinessList() {
		// TODO Auto-generated method stub
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		
		List<Business> list = new ArrayList<>();
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql="SELECT * FROM BUSINESS ";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				Business business = new Business();
				System.out.println(rs.getString("name"));
				business.setId(rs.getInt("id"));
				business.setName(rs.getString("name"));
				business.setTel(rs.getString("tel"));
				business.setQq(rs.getString("qq"));
				business.setEmail(rs.getString("email"));
				business.setShopname(rs.getString("shopname"));
				business.setAddress(rs.getString("address"));
				business.setTime(rs.getString("time"));
				business.setSimple(rs.getString("simple"));
				business.setState(rs.getString("state"));
				list.add(business);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return list;
	}

	@Override
	public int delBusiness(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "delete from BUSINESS  WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int changeState(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE BUSINESS SET STATE = '1' WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}


}

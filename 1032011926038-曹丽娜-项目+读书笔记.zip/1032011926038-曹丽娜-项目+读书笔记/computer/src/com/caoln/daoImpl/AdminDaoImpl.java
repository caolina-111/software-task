package com.caoln.daoImpl;

import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.PseudoColumnUsage;
import java.sql.ResultSet;

import com.caoln.bean.Admin;
import com.caoln.dao.AdminDao;
import com.caoln.jdbc.ConnectionPool;



/** 
 * @version 2019年2月24日20:42:45
 * 类说明 
 */
public class AdminDaoImpl implements AdminDao{

	@Override
	public Admin adminLogin(String name,String password) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Admin admin = new Admin();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT * FROM ADMIN WHERE NAME = ? AND PASSWORD = ?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				admin.setId(resultSet.getInt("id"));
				admin.setName(resultSet.getString("name"));
				admin.setPassword(resultSet.getString("password"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(preparedStatement, connection);
		}
		return admin;
	}

	@Override
	public int adminModifyPassword(int id, String new_psw) {
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE ADMIN SET PASSWORD=? WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, new_psw);
			ps.setInt(2, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

}

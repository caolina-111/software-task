package com.caoln.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.caoln.bean.Order;
import com.caoln.dao.OrderDao;
import com.caoln.jdbc.ConnectionPool;


public class OrderDaoImpl implements OrderDao {

	@Override
	public int insertOrder(Order order) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "INSERT INTO ORDERINFO VALUES(NULL,?,?,?,?,?,?,?,?)";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, order.getUser());
			ps.setInt(2, order.getProduct());
			ps.setString(3, order.getState());
			ps.setString(4, order.getTime());
			ps.setString(5, order.getIntime());
			ps.setString(6, order.getAddress());
			ps.setString(7, order.getNote());
			ps.setString(8, order.getType());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int delOrder(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "DELETE FROM ORDERINFO WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int modifyState(int id, String state) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE ORDERINFO SET STATE = ? WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, state);
			ps.setInt(2, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public List<Order> getOrderList() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Order> list = new ArrayList<Order>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT a.*,b.name as v_user from ORDERINFO a , user b where a.user = b.id";
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setId(rs.getInt("id"));
				order.setUser(rs.getInt("user"));
				order.setV_user(rs.getString("v_user"));
				order.setProduct(rs.getInt("product"));
				order.setState(rs.getString("state"));
				order.setTime(rs.getString("time"));
				order.setIntime(rs.getString("intime"));
				order.setNote(rs.getString("note"));
				order.setAddress(rs.getString("address"));
				order.setType(rs.getString("type"));
				list.add(order);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

	@Override
	public List<Order> getOrderListByUser(int user) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Order> list = new ArrayList<Order>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT a.*,b.title as v_product from ORDERINFO a , product b  WHERE a.USER = ? and a.product = b.id";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, user);
			rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setId(rs.getInt("id"));
				order.setUser(rs.getInt("user"));
				order.setProduct(rs.getInt("product"));
				order.setV_product(rs.getString("v_product"));
				order.setState(rs.getString("state"));
				order.setTime(rs.getString("time"));
				order.setIntime(rs.getString("intime"));
				order.setNote(rs.getString("note"));
				order.setAddress(rs.getString("address"));
				order.setType(rs.getString("type"));
				list.add(order);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

	@Override
	public int modifyTime(int id, String time) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE ORDERINFO SET time = ? WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, time);
			ps.setInt(2, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public List<Order> getOrderListByBusiness(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Order> list = new ArrayList<Order>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT a.*,b.title as v_product from ORDERINFO a , product b ,business c WHERE c.id = ? and a.product = b.id and b.business = c.id";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setId(rs.getInt("id"));
				order.setUser(rs.getInt("user"));
				order.setProduct(rs.getInt("product"));
				order.setV_product(rs.getString("v_product"));
				order.setState(rs.getString("state"));
				order.setTime(rs.getString("time"));
				order.setIntime(rs.getString("intime"));
				order.setNote(rs.getString("note"));
				order.setAddress(rs.getString("address"));
				order.setType(rs.getString("type"));
				list.add(order);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

}

package com.caoln.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.caoln.bean.User;
import com.caoln.dao.UserDao;
import com.caoln.jdbc.ConnectionPool;



/** 
 * 类说明 
 */
public class UserDaoImpl implements UserDao{

	@Override
	public User userLogin(String name, String password) {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		User user = new User();
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql="SELECT * FROM user WHERE  name = ?  AND password = ?";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			ps.setString(1,name);
			ps.setString(2,password);
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString("name"));
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setTel(rs.getString("tel"));
				user.setQq(rs.getString("qq"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return user;
	}

	@Override
	public int userRegister(User user) {
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "INSERT INTO USER VALUES(NULL,?,?,?,?)";
			ps = connection.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getTel());
			ps.setString(4, user.getQq());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int userModifyPassword(User user) {
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE USER SET PASSWORD = ? WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, user.getPassword());
			ps.setInt(2, user.getId());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public ArrayList<User> queryUserList() {
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<User> list = new ArrayList<User>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT * from USER";
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setTel(rs.getString("tel"));
				user.setQq(rs.getString("qq"));
				list.add(user);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

	@Override
	public int deleteUserById(int id) {
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "DELETE FROM USER WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int getUserNum() {
		Connection conn=null;
		PreparedStatement ps= null;
		ResultSet rs=null;
		int a = 0;
		try{
			//获取链接
			conn=ConnectionPool.getConnection();
			//定义SQL
			String sql = "SELECT COUNT(1) FROM USER";
			//SQL预处理
			ps= conn.prepareStatement(sql);
			//处理结果集
			rs = ps.executeQuery();
			while(rs.next()){
				a = rs.getInt(1);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			//关闭数据库
			ConnectionPool.close(rs, ps, conn);
			}			
		return a;
	}

}

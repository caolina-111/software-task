package com.caoln.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.caoln.bean.Product;
import com.caoln.dao.ProductDao;
import com.caoln.jdbc.ConnectionPool;


public class ProductDaoImpl implements ProductDao {

	@Override
	public int insertProduct(Product product) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "INSERT INTO PRODUCT VALUES(NULL,?,?,?,?,?)";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, product.getBusiness());
			ps.setString(2, product.getTitle());
			ps.setString(3, product.getPrice());
			ps.setString(4, product.getSimple());
			ps.setString(5, product.getUserule());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int delProduct(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		int b = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "DELETE FROM PRODUCT WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		} finally {
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product product = new Product();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT * from PRODUCT WHERE ID=?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				product.setId(rs.getInt("id"));
				product.setBusiness(rs.getInt("business"));
				product.setV_business(rs.getString("v_business"));
				product.setTitle(rs.getString("title"));
				product.setPrice(rs.getString("price"));
				product.setSimple(rs.getString("simple"));
				product.setUserule(rs.getString("userule"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return product;
	}

	@Override
	public List<Product> listProductByBusiness(int business) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Product> list = new ArrayList<Product>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT * from PRODUCT WHERE business = ?";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, business);
			rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setBusiness(rs.getInt("business"));
				product.setTitle(rs.getString("title"));
				product.setPrice(rs.getString("price"));
				product.setSimple(rs.getString("simple"));
				product.setUserule(rs.getString("userule"));
				list.add(product);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

	@Override
	public List<Product> listProduct() {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Product> list = new ArrayList<Product>();
		try {
			connection = ConnectionPool.getConnection();
			String sql = "SELECT * from PRODUCT";
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setBusiness(rs.getInt("business"));
				product.setV_business(rs.getString("v_business"));
				product.setTitle(rs.getString("title"));
				product.setPrice(rs.getString("price"));
				product.setSimple(rs.getString("simple"));
				product.setUserule(rs.getString("userule"));
				list.add(product);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			ConnectionPool.close(ps, connection);
		}
		return list;
	}

	@Override
	public int modifyProductPrice(int id, double price) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE PRODUCT SET PRICE = ? WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setDouble(1, price);
			ps.setInt(2, id);
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception2
			e.printStackTrace();
		} finally {
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

	@Override
	public int modifyProduct(Product product) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement ps = null;
		int a = 0;
		try {
			connection = ConnectionPool.getConnection();
			String sql = "UPDATE PRODUCT SET TITLE = ? , PRICE = ? , USERULE = ? , SIMPLE = ? WHERE ID = ?";
			ps = connection.prepareStatement(sql);
			ps.setString(1, product.getTitle());
			ps.setString(2, product.getPrice());
			ps.setString(3, product.getUserule());
			ps.setString(4, product.getSimple());
			ps.setInt(5, product.getId());
			a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			ConnectionPool.close(ps, connection);
		}
		return a;
	}

}

package com.caoln.bean;

public class Product {
	private Integer id;
	private Integer business;
	private String v_business;
	private String title;
	private String price;
	private String simple;
	private String userule;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBusiness() {
		return business;
	}
	public void setBusiness(Integer business) {
		this.business = business;
	}
	public String getV_business() {
		return v_business;
	}
	public void setV_business(String v_business) {
		this.v_business = v_business;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getSimple() {
		return simple;
	}
	public void setSimple(String simple) {
		this.simple = simple;
	}
	public String getUserule() {
		return userule;
	}
	public void setUserule(String userule) {
		this.userule = userule;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", business=" + business + ", v_business=" + v_business + ", title=" + title
				+ ", price=" + price + ", simple=" + simple + ", userule=" + userule + "]";
	}
	

}

package com.caoln.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.caoln.bean.Business;
import com.caoln.daoImpl.BusinessDaoImpl;


/**
 * Servlet implementation class BusinessAction
 */
@WebServlet("/BusinessAction")
public class BusinessAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusinessAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String type = request.getParameter("type");
		
		
		if (type.equals("login")) {
			//商家登录方法
			Business business = null;
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			business = businessDaoImpl.businessLogin(request.getParameter("username"), request.getParameter("password"));
			System.out.println(business.toString());
			if (business.getName()!=null) {
				HttpSession session = request.getSession();
				session.setAttribute("businessinfo", business);
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else {
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
			
		}else if (type.equals("register")) {
			//商家注册方法
			Business business = new Business();
			business.setName(request.getParameter("name"));
			business.setPassword(request.getParameter("password"));
			business.setTel(request.getParameter("tel"));
			business.setQq(request.getParameter("qq"));
			business.setEmail(request.getParameter("email"));
			business.setShopname(request.getParameter("shopname"));
			business.setSimple(request.getParameter("simple"));
			business.setTime(request.getParameter("time"));
			business.setAddress(request.getParameter("address"));
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			int a = businessDaoImpl.businessRegister(business);
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
			
			
		}else if (type.equals("update")) {
			//商家修改信息方法
			
		}else if(type.equals("name")){
			//获取店铺名称列表
			List<String> shopname = new ArrayList<String>();
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			shopname = businessDaoImpl.getShopNameList();
			if (shopname.size() > 0) {
				JSONObject name = new JSONObject();
				name.put("shopname", shopname);
				name.put("resault", "ok");
				PrintWriter printWriter = response.getWriter();
				printWriter.print(name);
				printWriter.flush();
				printWriter.close();
			}
			
		}else if (type.equals("modify")) {
			String password = request.getParameter("password");
			int id = Integer.valueOf(request.getParameter("id"));
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			int a = businessDaoImpl.changePassword(id, password);
			if(a>0){
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("change")) {
			Business business = new Business();
			int id = Integer.valueOf(request.getParameter("shopid"));
			business.setId(id);
			business.setTel(request.getParameter("tel"));
			business.setQq(request.getParameter("qq"));
			business.setEmail(request.getParameter("email"));
			business.setAddress(request.getParameter("address"));
			business.setTime(request.getParameter("time"));
			business.setSimple(request.getParameter("simple"));
			/*business.setShopname(request.getParameter("shopname"));
			business.setName(request.getParameter("name"));*/
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			int a = businessDaoImpl.changeBusinessInfo(business);
			if(a>0){
				/*HttpSession session = request.getSession();
				session.setAttribute("userinfo", business);*/
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if(type.equals("listn")){
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			List<Business> list = businessDaoImpl.getBusinessInfoByName(request.getParameter("name"));
			JSONObject name = new JSONObject();
			name.put("shoplist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(name);
			printWriter.flush();
			printWriter.close();
		}else if(type.equals("list")){
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			List<Business> list = businessDaoImpl.getBusinessList();
			JSONObject name = new JSONObject();
			name.put("shoplist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(name);
			printWriter.flush();
			printWriter.close();
		}else if (type.equals("del")) {
			int id = Integer.valueOf(request.getParameter("id"));
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			int a = businessDaoImpl.delBusiness(id);
			if(a>0){
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("state")) {
			int id = Integer.valueOf(request.getParameter("id"));
			BusinessDaoImpl businessDaoImpl = new BusinessDaoImpl();
			int a = businessDaoImpl.changeState(id);
			if(a>0){
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}
		
		
	}

}

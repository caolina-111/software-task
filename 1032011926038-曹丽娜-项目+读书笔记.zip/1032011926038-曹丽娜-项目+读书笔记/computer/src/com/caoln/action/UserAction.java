package com.caoln.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.caoln.bean.User;
import com.caoln.dao.UserDao;
import com.caoln.daoImpl.UserDaoImpl;



/**
 * Servlet implementation class UserAction
 */
@WebServlet("/UserAction")
public class UserAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String type = request.getParameter("type");
		
		if (type.equals("login")) {
			User user = null;
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			user = userDaoImpl.userLogin(request.getParameter("name"), request.getParameter("password"));
			
			System.out.println(user.toString());
			if (user.getName()!=null) {
				user.toString();
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", user);
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else {
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("reg")) {
			User user = new User();
			user.setName(request.getParameter("name"));
			user.setPassword(request.getParameter("password"));
			user.setTel(request.getParameter("tel"));
			user.setQq(request.getParameter("qq"));
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			int a = userDaoImpl.userRegister(user);
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("list")) {
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			List<User> list = userDaoImpl.queryUserList();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("userlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}else if(type.equals("del")) {
			int id = Integer.parseInt(request.getParameter("id"));
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			int a = userDaoImpl.deleteUserById(id);
			if(a>0){
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("modify")) {
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			User user = new User();
			user.setId(Integer.parseInt(request.getParameter("id")));
			user.setPassword(request.getParameter("password"));
			int a = userDaoImpl.userModifyPassword(user);
			if(a>0){
				HttpSession session = request.getSession();
				session.invalidate();
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
			
			
		}
		
		
		
	}

}

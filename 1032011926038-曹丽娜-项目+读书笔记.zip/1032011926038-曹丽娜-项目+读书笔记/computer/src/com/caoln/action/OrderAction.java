package com.caoln.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.caoln.bean.Order;
import com.caoln.daoImpl.OrderDaoImpl;
import com.caoln.tool.CommonTools;



/**
 * Servlet implementation class UserAction
 */
@WebServlet("/OrderAction")
public class OrderAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String type = request.getParameter("type");
		CommonTools commonTools = new CommonTools();
		
		if (type.equals("add")) {
			Order order = new Order();
			order.setUser(Integer.valueOf(request.getParameter("user")));
			order.setProduct(Integer.valueOf(request.getParameter("product")));
			order.setIntime(commonTools.getTime2());
			order.setTime(request.getParameter("time"));
			order.setState("等待上门");
			order.setAddress(request.getParameter("address"));
			order.setNote(request.getParameter("note"));
			order.setType(request.getParameter("otype"));
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			int a = orderDaoImpl.insertOrder(order);
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("del")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			int a = orderDaoImpl.delOrder(Integer.valueOf(request.getParameter("id")));
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("modify")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			int a = orderDaoImpl.modifyState(Integer.valueOf(request.getParameter("id")), request.getParameter("state"));
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("modifyt")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			int a = orderDaoImpl.modifyTime(Integer.valueOf(request.getParameter("id")), request.getParameter("time"));
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if(type.equals("list")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			List<Order> list = orderDaoImpl.getOrderList();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("orderlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}else if(type.equals("listu")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			List<Order> list = orderDaoImpl.getOrderListByUser(Integer.valueOf(request.getParameter("id")));
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("orderlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}else if(type.equals("listb")) {
			OrderDaoImpl orderDaoImpl = new OrderDaoImpl();
			List<Order> list = orderDaoImpl.getOrderListByBusiness(Integer.valueOf(request.getParameter("id")));
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("orderlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}
		
		
		
	}

}

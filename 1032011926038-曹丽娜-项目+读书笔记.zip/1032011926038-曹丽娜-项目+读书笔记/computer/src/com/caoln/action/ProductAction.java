package com.caoln.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.caoln.bean.Product;
import com.caoln.daoImpl.ProductDaoImpl;



/**
 * Servlet implementation class UserAction
 */
@WebServlet("/ProductAction")
public class ProductAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String type = request.getParameter("type");
		
		if (type.equals("add")) {
			Product product = new Product();
			product.setBusiness(Integer.valueOf(request.getParameter("business")));
			product.setTitle(request.getParameter("title"));
			product.setPrice(request.getParameter("price"));
			product.setSimple(request.getParameter("simple"));
			product.setUserule(request.getParameter("userule"));
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			int a = productDaoImpl.insertProduct(product);
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("del")) {
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			int a = productDaoImpl.delProduct(Integer.valueOf(request.getParameter("id")));
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("get")) {
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			Product product = productDaoImpl.getProduct(Integer.valueOf(request.getParameter("id")));
			HttpSession session = request.getSession();
			session.setAttribute("productinfo", product);
			request.getRequestDispatcher("/user/details.jsp").forward(request, response);
		}else if(type.equals("listb")) {
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			List<Product> list = productDaoImpl.listProductByBusiness(Integer.valueOf(request.getParameter("business")));
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("productlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}else if(type.equals("list")) {
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			List<Product> list = productDaoImpl.listProduct();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("productlist", list);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(jsonObject);
			printWriter.flush();
			printWriter.close();
		}else if (type.equals("modifyp")) {
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			int a = productDaoImpl.modifyProductPrice(Integer.valueOf(request.getParameter("id")), Double.valueOf(request.getParameter("price")));
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}else if (type.equals("modify")) {
			Product product = new Product();
			product.setId(Integer.valueOf(request.getParameter("id")));
			product.setTitle(request.getParameter("title"));
			product.setPrice(request.getParameter("price"));
			product.setSimple(request.getParameter("simple"));
			product.setUserule(request.getParameter("userule"));
			ProductDaoImpl productDaoImpl = new ProductDaoImpl();
			int a = productDaoImpl.modifyProduct(product);
			if (a>0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			}else{
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		}
		
		
		
	}

}

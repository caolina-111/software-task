package com.caoln.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.caoln.bean.Admin;
import com.caoln.daoImpl.AdminDaoImpl;




/**
 * Servlet implementation class AdminAction
 */
@WebServlet("/AdminAction")
public class AdminAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("utf-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String type = request.getParameter("type");

		if (type.equals("login")) {
			Admin admin = null;
			AdminDaoImpl adminDaoImpl = new AdminDaoImpl();
			admin = adminDaoImpl.adminLogin(request.getParameter("name"), request.getParameter("password"));
			if (admin.getName() != null) {
				HttpSession session = request.getSession();
				session.setAttribute("admininfo", admin);
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			} else {
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		} else if (type.equals("modify")) {
			int id = Integer.parseInt(request.getParameter("id"));
			String new_password = request.getParameter("password");
			AdminDaoImpl adminDaoImpl = new AdminDaoImpl();
			int a = adminDaoImpl.adminModifyPassword(id, new_password);
			if (a > 0) {
				PrintWriter pw = response.getWriter();
				pw.print("ok");
				pw.flush();
			} else {
				PrintWriter pw = response.getWriter();
				pw.print("error");
				pw.flush();
			}
		} 

	}

}

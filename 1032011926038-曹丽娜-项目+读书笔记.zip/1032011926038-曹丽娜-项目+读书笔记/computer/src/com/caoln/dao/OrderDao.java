package com.caoln.dao;

import java.util.List;

import com.caoln.bean.Order;


public interface OrderDao {
	
	/**
	 * 新增订单
	 * @param order
	 * @return
	 */
	public int insertOrder(Order order);
	
	/**
	 * 删除订单
	 * @param id
	 * @return
	 */
	public int delOrder(int id);
	
	/**
	 * 修改订单状态
	 * @param id
	 * @param state
	 * @return
	 */
	public int modifyState(int id , String state);
	
	/**
	 * 获取全部订单
	 * @return
	 */
	public List<Order> getOrderList();
	
	/**
	 * 获取用户的全部订单
	 * @param user
	 * @return
	 */
	public List<Order> getOrderListByUser(int user);
	
	/**
	 * 修改订单预定时间
	 * @param id
	 * @param time
	 * @return
	 */
	public int modifyTime(int id , String time);
	
	/**
	 * 获取商家的全部订单
	 * @param user
	 * @return
	 */
	public List<Order> getOrderListByBusiness(int id);

}

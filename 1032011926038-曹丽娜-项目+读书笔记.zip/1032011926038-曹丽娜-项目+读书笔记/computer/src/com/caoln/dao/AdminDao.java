package com.caoln.dao;

import com.caoln.bean.Admin;

/** 
 * 类说明 
 */
public interface AdminDao {
	
	/**
	 * 管理员登录方法
	 * @return
	 */
	public Admin adminLogin(String name,String password);
	
	/**
	 * 管理员修改密码
	 * @param id
	 * @param old_psw
	 * @param new_psw
	 * @return
	 */
	public int adminModifyPassword(int id,String new_psw);

}

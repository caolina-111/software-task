package com.caoln.dao;

import java.util.List;

import com.caoln.bean.Business;


/** 
 * @author 作者 :曹丽娜
 * @author 
 * @version 创建时间：2018年1月14日 下午10:27:32 
 * 类说明 
 */
public interface BusinessDao {
	/**
	 * 商家登录方法
	 * @author 曹丽娜
	 * @param name
	 * @param password
	 * @return
	 */
	public Business businessLogin(String name, String password);
	
	/**
	 * 商家注册方法
	 * @author 曹丽娜
	 * @param user
	 * @return
	 */
	public int businessRegister(Business business );
	
	/**
	 * 获取商家名列表
	 * @author 曹丽娜
	 * @return
	 */
	public List<String> getShopNameList();
	
	/**
	 * 根据名称查询店铺列表
	 * @author 曹丽娜
	 * @return
	 */
	public List<Business> getBusinessInfoByName(String name);
	
	/**
	 * 商家修改密码方法
	 * @param id
	 * @param password
	 * @return
	 */
	public int changePassword(int id , String password);
	
	/**
	 * 修改店铺信息方法
	 * @param business
	 * @return
	 */
	public int changeBusinessInfo(Business business);
	
	/**
	 * 获取全部商铺列表
	 * @author 曹丽娜
	 * @return
	 */
	public List<Business> getBusinessList();
	
	/**
	 * 删除商家方法
	 * @param id
	 * @param password
	 * @return
	 */
	public int delBusiness(int id);
	
	/**
	 * 商家审核通过方法
	 * @param id
	 * @return
	 */
	public int changeState(int id);
	
}

package com.caoln.dao;

import java.util.List;

import com.caoln.bean.Product;


public interface ProductDao {
	/**
	 * 新增商品
	 * @param product
	 * @return
	 */
	public int insertProduct(Product product);
	
	/**
	 * 删除商品
	 * @param id
	 * @return
	 */
	public int delProduct(int id);

	/**
	 * 获取单个商品信息
	 * @param id
	 * @return
	 */
	public Product getProduct(int id);
	
	/**
	 * 按商家获取商品
	 * @param name
	 * @return
	 */
	public List<Product> listProductByBusiness(int business);
	
	/**
	 * 获取全部商品
	 * @param name
	 * @return
	 */
	public List<Product> listProduct();
	
	/**
	 * 修改商品价格
	 * @param id
	 * @param price
	 * @return
	 */
	public int modifyProductPrice(int id , double price);
	
	/**
	 * 修改商品信息
	 * @param id
	 * @param price
	 * @return
	 */
	public int modifyProduct(Product product);
}

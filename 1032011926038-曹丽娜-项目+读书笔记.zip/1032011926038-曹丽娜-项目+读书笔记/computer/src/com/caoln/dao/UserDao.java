package com.caoln.dao;

import java.util.ArrayList;
import java.util.List;

import com.caoln.bean.User;



/** 
 * 类说明 
 */
public interface UserDao {
	
	/**
	 * 用户登录方法
	 * @param name
	 * @param password
	 * @return
	 */
	public User userLogin(String name,String password);
	
	/**
	 * 用户注册方法
	 * @param user
	 * @return
	 */
	public int userRegister(User user);
	
	/**
	 * 用户修改密码
	 * @param user
	 * @return
	 */
	public int userModifyPassword(User user);
	
	/**
	 * 获取全部用户列表
	 * @return
	 */
	public ArrayList<User> queryUserList();
	
	/**
	 * 删除用户方法
	 * @param id
	 * @return
	 */
	public int deleteUserById(int id);

	/**
	 * 获取用户总数
	 * @return
	 */
	public int getUserNum();
	
}

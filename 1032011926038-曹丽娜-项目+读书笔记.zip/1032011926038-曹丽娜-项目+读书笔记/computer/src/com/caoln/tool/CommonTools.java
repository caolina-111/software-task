package com.caoln.tool;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
/** 
 * @author 
 * @author 
 * @version 
 * 类说明 
 */
public class CommonTools {
	
	
	/**
	 * 获取时间  格式 2016-12-12
	 * @return
	 */
	public String getTime(){
		SimpleDateFormat simpleDateFormat;  
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");  
        Date date = new Date();  
        String str = simpleDateFormat.format(date);  
        return str;// 当前时间  
	}
	
	public String getTime2(){
		SimpleDateFormat simpleDateFormat;  
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        Date date = new Date();  
        String str = simpleDateFormat.format(date);  
        return str;// 当前时间  
	}
	
	
	/**
	 * 获取随机的文件名  当前时间(20161220172045)+随机数
	 * @return
	 */
	public String getFileName(){
		SimpleDateFormat simpleDateFormat;  
        simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");  
        Date date = new Date();  
        String str = simpleDateFormat.format(date);  
        Random random = new Random();  
        int rannum = (int) (random.nextDouble() * (999 - 100 + 1)) + 100;// 获取5位随机数  
        return str + rannum;// 当前时间  
	}
	
	
	
	/**
	 * 获取文件大小字符串
	 * @param size  文档大小  LONG型
	 * @return
	 */
	public String convertFileSize(long size) {
        long kb = 1024;
        long mb = kb * 1024;
        long gb = mb * 1024;
 
        if (size >= gb) {
            return String.format("%.1f GB", (float) size / gb);
        } else if (size >= mb) {
            float f = (float) size / mb;
            return String.format(f > 100 ? "%.0f MB" : "%.1f MB", f);
        } else if (size >= kb) {
            float f = (float) size / kb;
            return String.format(f > 100 ? "%.0f KB" : "%.1f KB", f);
        } else
            return String.format("%d B", size);
    }
	
	
	/**
	 * 获取文档类型名
	 * @param type
	 * @return
	 */
	public String getFileType(String type){
		String filetype = null;
		if (type.equals("docx")||type.equals("doc")) {
			filetype = "word";
		}else if (type.equals("pdf")) {
			filetype = "pdf";
		}else if (type.equals("ppt")||type.equals("pptx")) {
			filetype = "ppt";
		}else if (type.equals("xls")||type.equals("xlsx")) {
			filetype = "xls";
		}else if (type.equals("rar")||type.equals("zip")||type.equals("RAR")||type.equals("ZIP")) {
			
		}else {
			filetype = "default";
		}
		return filetype;
	}
	
	/**
	 * 获取客户端IP地址
	 * @param request
	 * @return
	 */
	public static String getIp(HttpServletRequest request) {
        String remoteAddr = request.getRemoteAddr();
        String forwarded = request.getHeader("X-Forwarded-For");
        String realIp = request.getHeader("X-Real-IP");

        String ip = null;
        if (realIp == null) {
            if (forwarded == null) {
                ip = remoteAddr;
            } else {
                ip = remoteAddr + "/" + forwarded;
            }
        } else {
            if (realIp.equals(forwarded)) {
                ip = realIp;
            } else {
                ip = realIp + "/" + forwarded.replaceAll(", " + realIp, "");
            }
        }
        return ip;
    }
	
	
	/**
	 * 时间格式转换方法
	 * @param size
	 * @return
	 */
	public String convertTime(String time) {
		return time.replace("/", "-");
    }
	
	/**
	 * 获取月份格式
	 * @param size
	 * @return
	 */
	public String getMonth(String time) {
		String[] times = time.split("-");
		return times[1];
    }

}

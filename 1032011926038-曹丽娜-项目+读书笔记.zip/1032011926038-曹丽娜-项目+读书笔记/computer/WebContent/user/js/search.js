var userId;
$(function() {
	
	
	$('#appointTime').datetimepicker({
		format: 'yyyy-mm-dd hh:ii', //显示格式可为yyyymm/yyyy-mm-dd/yyyy.mm.dd
		language: 'zh-CN' //语言
	});
	
});

function searchShop(){
	$.ajax({
		type: "post",
		url: "/computer/BusinessAction?type=listn",
		data: {name:$("#name").val()},
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			var list = data.shoplist;
			$("#shopnum").empty().append("共找到 "+list.length+" 家店铺");
			var text = "";
			for(var i = 0 ; i < list.length ; i++){
				text += "<div class=\"col-md-4 col-sm-4 details-grid-w3lsagile details-grid-3-w3lsagile\">";
				text += "<div class=\"details-grid3-w3lsagile agile_services_grid\">";
				text += "<div class=\"details-grid-info-w3lsagile\">";
				text += "<h4>"+list[i].name+"</h4>";
				text += "<p>"+list[i].simple+"</p>";
				text += "<p>店铺地址："+list[i].address+"</p>";
				text += "<p>联系方式："+list[i].tel+"</p>";
				text += "<p>营业时间："+list[i].time+"</p>";
				text += "</div>";
				text += "<div class=\"agileits-button details_w3ls\">";
				text += "<a href=\"javascript:void(0);\" class=\"btn btn-primary\" onclick=\"openModal('"+list[i].id+"')\">立即预约 <i class=\"fa fa-long-arrow-right\" aria-hidden=\"true\"></i></a>";
				text += "</div>";
				text += "<div class=\"clearfix\"></div>";
				text += "</div>";
				text += "</div>";
			}
			$("#shopInfo").empty().append(text);
		}
	});
	
	
}

function openModal(id){
	userId = $("#userid").val();
	if (userId == null || userId == "") {
		alert("请先登录！");
		location.href = "/computer/user/login.jsp";
		return false;
	}
	$("#myModal").modal('show');
	$("#businessId").val(id);
	loadProductList(id);
}

function addOrder(){
	if($("#otype").val() == "上门维修"){
		if ($("#address").val() == null || $("#address").val() == "") {
			$("#err").empty().append("上门维修地址不能为空！");
			return false;
		}
	}
	
	if ($("#appointTime").val() == null || $("#appointTime").val() == "") {
		$("#err").empty().append("预约时间不能为空！");
		return false;
	}
	$.ajax({
		type: "post",
		url: "/computer/OrderAction?type=add",
		data: $("#addOrder").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok"){
				alert("预约成功！");
				$("#myModal").modal('hide');
			}else{
				alert("预约失败！");
			}
		}
	});
	
}

function loadProductList(id){
	$.ajax({
		type: "post",
		url: "/computer/ProductAction?type=listb",
		data: {business:id},
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			var list = data.productlist;
			var text = "";
			for(var i = 0 ; i < list.length ; i++){
				text += "<option value=\""+list[i].id+"\">"+list[i].title+"- 价格："+list[i].price+"-"+list[i].simple+"</option>";
			$("#product").empty().append(text);
		}
		}
	});
}


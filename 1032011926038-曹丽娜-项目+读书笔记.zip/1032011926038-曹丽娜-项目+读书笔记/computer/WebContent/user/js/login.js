$(function() {
	

});

function login(){
	if($("#username").val() == null || $("#username").val() == ""){
		$("#err").empty().append("用户名不能为空！");
		return false;
	}
	if($("#password").val() == null || $("#password").val() == ""){
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	$.ajax({
		type: "post",
		url: "/computer/UserAction?type=login",
		data: $("#user_login").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok") {
				location.href = "/computer/index.jsp";
			} else {
				$("#err").empty().append("用户名或密码错误，请重新输入！");
			}
		}
	});
	
	
}

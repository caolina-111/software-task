var postage;
var userId;
$(function() {
	userId = $("#userid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/user/login.jsp";
		return false;
	}
	getNowFormatDate();
});


function mpdifyPassword() {
	if ($("#password").val() == null || $("#password").val() == "") {
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if ($("#password2").val() == null || $("#password2").val() == "") {
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if ($("#password").val() != $("#password2").val()) {
		$("#err").empty().append("两次输入密码不一致！");
		return false;
	}
	$.ajax({
		type : "post",
		// url: "/print/UserAction?type=login",
		url : "/computer/UserAction?type=modify",
		data : $("#modifyPassword").serialize(),
		async : true,
		dataType : "text",
		error : function(request) {
			layer.msg('修改失败！请重试！', {icon: 2});
		},
		success : function(data) {
			if (data == "ok") {
				alert('修改成功！请重新登陆！');
				location.href = "/computer/user/login.jsp";
				
			} else {
				alert('修改失败！请重试！');
			}
		}
	});
}

function getNowFormatDate() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year  + month  + strDate;
    $("#year").empty().append(year);
    $("#month").empty().append(month);
    $("#day").empty().append(strDate);
}



var postage;
var userId;
$(function() {
	userId = $("#userid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/user/login.jsp";
		return false;
	}
	
	$('#appointTime').datetimepicker({
		format: 'yyyy-mm-dd hh:ii', //显示格式可为yyyymm/yyyy-mm-dd/yyyy.mm.dd
		language: 'zh-CN' //语言
	});
	
	loadUserOrder();
	
	
});


function finishOrder(id) {
	if(confirm("确认完成订单吗？")){
		$.ajax({
			type : "post",
			url : "/computer/OrderAction?type=modify",
			data : {
				id : id,
				state:"已完成"
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("订单已完成！");
					loadUserOrder();
				}else{
					alert("订单完成失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function delOrder(id) {
	if(confirm("确认删除订单吗？")){
		$.ajax({
			type : "post",
			url : "/computer/OrderAction?type=del",
			data : {
				id : id
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("订单已删除！");
					loadUserOrder();
				}else{
					alert("订单删除失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function loadUserOrder() {
	$.ajax({
		type: "post",
		url: "/computer/OrderAction?type=listu",
		data: {
			id: userId
		},
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data.orderlist.length > 0) {
				var list = data.orderlist;
				var text = "";
				for(var i = 0; i < list.length; i++) {
					text += "<tr>";
					text += "<td>"+list[i].id+"</td>";
					text += "<td>"+list[i].v_product+"</td>";
					text += "<td>"+list[i].time+"</td>";
					text += "<td>"+list[i].state+"</td>";
					text += "<td>"+list[i].intime+"</td>";
					text += "<td>"+list[i].type+"</td>";
					text += "<td>"+list[i].note+"</td>";
					text += "<td>";
					text += "<span class=\"label label-warning\" onclick=\"openModal('"+list[i].id+"')\">修改预约时间</span> ";
					if(list[i].state == "已完成"){
					}else{
						text += "<span class=\"label label-success\" onclick=\"finishOrder('"+list[i].id+"')\">完成订单</span> ";
					}
					text += "<span class=\"label label-danger\" onclick=\"delOrder('"+list[i].id+"')\">删除订单</span> ";
					text += "</td>";
					text += "</tr>";
				}
				$("#orderInfo").empty().append(text);
			}
		}
	});
}


function openModal(id){
	$("#myModal").modal('show');
	$("#id").val(id);
}

function modifyOrder(){
	if ($("#appointTime").val() == null || $("#appointTime").val() == "") {
		$("#err").empty().append("预约时间不能为空！");
		return false;
	}
	$.ajax({
		type : "post",
		url : "/computer/OrderAction?type=modifyt&id="+$("#id").val(),
		data : {
			time : $("#appointTime").val()
		},
		async : true,
		dataType : "text",
		error : function(request) {
			alert("网络请求错误，请重试！");
		},
		success : function(data) {
			if (data == "ok") {
				alert("预约时间修改成功！");
				loadUserOrder();
			}else{
				alert("预约时间修改失败！请重试！");
			}
		}
	});
}

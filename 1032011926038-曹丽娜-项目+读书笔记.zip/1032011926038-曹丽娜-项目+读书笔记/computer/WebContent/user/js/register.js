$(function() {

});

function register(){
	if($("#name").val() == null || $("#name").val() == ""){
		$("#err").empty().append("用户名不能为空！");
		return false;
	}
	if($("#password").val() == null || $("#password").val() == ""){
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if($("#tel").val() == null || $("#tel").val() == ""){
		$("#err").empty().append("电话号码不能为空！");
		return false;
	}
	if(!/^1\d{10}$/.test($("#tel").val())){
		$("#err").empty().append("电话号码格式不正确！");
		return false;
	}
	if($("#qq").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("QQ号不能为空！");
		return false;
	}
	
	$.ajax({
		type: "post",
		url: "/computer/UserAction?type=reg",
		data: $("#registerInfo").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok") {
				alert("注册成功！请登录！");
				location.href = "/computer/user/login.jsp";
			} else {
				$("#err").empty().append("注册失败，请重试！");
			}
		}
	});
	
	
}

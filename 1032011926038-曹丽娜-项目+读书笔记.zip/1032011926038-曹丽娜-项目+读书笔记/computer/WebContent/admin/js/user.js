var postage;
var userId;
$(function() {
	userId = $("#adminid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/admin/login.jsp";
		return false;
	}
	loadUserList();
	
	
});


function delUser(id) {
	if(confirm("确认删除用户吗？")){
		$.ajax({
			type : "post",
			url : "/computer/UserAction?type=del",
			data : {
				id : id
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("用户已删除！");
					loadUserList();
				}else{
					alert("用户删除失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function loadUserList() {
	$.ajax({
		type: "post",
		url: "/computer/UserAction?type=list",
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data.userlist.length > 0) {
				var list = data.userlist;
				var text = "";
				for(var i = 0; i < list.length; i++) {
					text += "<tr>";
					text += "<td>"+list[i].id+"</td>";
					text += "<td>"+list[i].name+"</td>";
					text += "<td>"+list[i].tel+"</td>";
					text += "<td>"+list[i].qq+"</td>";
					text += "<td>";
					text += "<span class=\"label label-danger\" onclick=\"delUser('"+list[i].id+"')\">删除</span>";
					text += "</td>";
					text += "</tr>";
				}
				$("#userInfo").empty().append(text);
			}
		}
	});
}


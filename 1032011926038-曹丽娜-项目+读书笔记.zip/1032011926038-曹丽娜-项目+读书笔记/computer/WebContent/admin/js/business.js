var postage;
var userId;
$(function() {
	userId = $("#adminid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/admin/login.jsp";
		return false;
	}
	loadBusinessList();
	
	
});


function delBusiness(id) {
	if(confirm("确认删除用户吗？")){
		$.ajax({
			type : "post",
			url : "/computer/BusinessAction?type=del",
			data : {
				id : id
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("用户已删除！");
					loadBusinessList();
				}else{
					alert("用户删除失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function changeBusinessState(id) {
	if(confirm("确认通过商家审核吗？")){
		$.ajax({
			type : "post",
			url : "/computer/BusinessAction?type=state",
			data : {
				id : id
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("审核通过！");
					loadBusinessList();
				}else{
					alert("审核失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function loadBusinessList() {
	$.ajax({
		type: "post",
		url: "/computer/BusinessAction?type=list",
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data.shoplist.length > 0) {
				var list = data.shoplist;
				var text = "";
				for(var i = 0; i < list.length; i++) {
					text += "<tr>";
					text += "<td>"+list[i].id+"</td>";
					text += "<td>"+list[i].name+"</td>";
					text += "<td>"+list[i].tel+"</td>";
					text += "<td>"+list[i].qq+"</td>";
					text += "<td>"+list[i].email+"</td>";
					text += "<td>"+list[i].shopname+"</td>";
					text += "<td>"+list[i].address+"</td>";
					text += "<td>"+list[i].time+"</td>";
					text += "<td>"+list[i].simple+"</td>";
					if(list[i].state == '0'){
						text += "<td>待审核</td>";
					}else{
						text += "<td>审核通过</td>";
					}
					text += "<td>";
					if(list[i].state == '0'){
						text += "<button type=\"button\" class=\"label label-success\" onclick=\"changeBusinessState('"+list[i].id+"')\">审核通过</button> ";
					}else{
					}
					text += "<button type=\"button\" class=\"label label-danger\" onclick=\"delBusiness('"+list[i].id+"')\">删除</button>";
					text += "</td>";
					text += "</tr>";
				}
				$("#businessInfo").empty().append(text);
			}
		}
	});
}


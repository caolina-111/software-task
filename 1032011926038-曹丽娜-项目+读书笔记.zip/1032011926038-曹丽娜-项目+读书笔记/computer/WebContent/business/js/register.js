$(function() {

});

function register(){
	if($("#name").val() == null || $("#name").val() == ""){
		$("#err").empty().append("用户名不能为空！");
		return false;
	}
	if($("#password").val() == null || $("#password").val() == ""){
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if($("#tel").val() == null || $("#tel").val() == ""){
		$("#err").empty().append("电话号码不能为空！");
		return false;
	}
	if(!/^1\d{10}$/.test($("#tel").val())){
		$("#err").empty().append("电话号码格式不正确！");
		return false;
	}
	if($("#qq").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("QQ号不能为空！");
		return false;
	}
	if($("#email").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("邮箱不能为空！");
		return false;
	}
	if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test($("#email").val())){
		$("#err").empty().append("邮箱格式不正确！");
		return false;
	}
	if($("#shopname").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("店铺名不能为空！");
		return false;
	}
	if($("#address").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("地址不能为空！");
		return false;
	}
	if($("#time").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("营业时间不能为空！");
		return false;
	}
	if($("#simple").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("简介不能为空！");
		return false;
	}
	$.ajax({
		type: "post",
		url: "/computer/BusinessAction?type=register",
		data: $("#registerInfo").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok") {
				alert("注册成功！请等待管理员审核！");
				location.href = "/computer/business/login.jsp";
			} else {
				$("#err").empty().append("注册失败，请重试！");
			}
		}
	});
	
	
}

var postage;
var userId;
$(function() {
	userId = $("#businessid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/business/login.jsp";
		return false;
	}
	getNowFormatDate();
});


function mpdifyPassword() {
	if ($("#password").val() == null || $("#password").val() == "") {
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if ($("#password2").val() == null || $("#password2").val() == "") {
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	if ($("#password").val() != $("#password2").val()) {
		$("#err").empty().append("两次输入密码不一致！");
		return false;
	}
	$.ajax({
		type : "post",
		// url: "/print/UserAction?type=login",
		url : "/computer/BusinessAction?type=modify",
		data : $("#modifyPassword").serialize(),
		async : true,
		dataType : "text",
		error : function(request) {
			alert('修改失败！请重试！');
		},
		success : function(data) {
			if (data == "ok") {
				alert('修改成功！请重新登陆！');
				location.href = "/computer/business/login.jsp";
				
			} else {
				alert('修改失败！请重试！');
			}
		}
	});
}


function modifyBusiness() {
	if($("#tel").val() == null || $("#tel").val() == ""){
		$("#err").empty().append("电话号码不能为空！");
		return false;
	}
	if($("#qq").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("QQ号不能为空！");
		return false;
	}
	if($("#email").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("邮箱不能为空！");
		return false;
	}
	if($("#address").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("地址不能为空！");
		return false;
	}
	if($("#time").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("营业时间不能为空！");
		return false;
	}
	if($("#simple").val() == null || $("#qq").val() == ""){
		$("#err").empty().append("简介不能为空！");
		return false;
	}
	$.ajax({
		type : "post",
		url : "/computer/BusinessAction?type=change",
		data : $("#modifyInfo").serialize(),
		async : true,
		dataType : "text",
		error : function(request) {
			alert('修改失败！请重试！');
		},
		success : function(data) {
			if (data == "ok") {
				alert('修改成功！请重新登陆！');
				location.href = "/computer/business/login.jsp";
				
			} else {
				alert('修改失败！请重试！');
			}
		}
	});
}

function getNowFormatDate() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year  + month  + strDate;
    $("#year").empty().append(year);
    $("#month").empty().append(month);
    $("#day").empty().append(strDate);
}


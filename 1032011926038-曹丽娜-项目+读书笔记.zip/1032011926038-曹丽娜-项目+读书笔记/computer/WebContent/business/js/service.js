var postage;
var userId;
$(function() {
	userId = $("#businessid").val();
	if (userId == null || userId == "") {
		location.href = "/computer/business/login.jsp";
		return false;
	}
	
	loadBusinessProduct();
	
	
});

function loadBusinessProduct() {
	$.ajax({
		type: "post",
		url: "/computer/ProductAction?type=listb",
		data: {
			business: userId
		},
		async: true,
		dataType: "json",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data.productlist.length > 0) {
				var list = data.productlist;
				var text = "";
				for(var i = 0; i < list.length; i++) {
					text += "<tr>";
					text += "<td>"+list[i].id+"</td>";
					text += "<td>"+list[i].title+"</td>";
					text += "<td>"+list[i].price+"</td>";
					text += "<td>"+list[i].simple+"</td>";
					text += "<td>"+list[i].userule+"</td>";
					text += "<td>";
					text += "<span class=\"label label-warning\" onclick=\"openModal(this)\">修改服务信息</span> ";
					text += "<span class=\"label label-danger\" onclick=\"delProduct('"+list[i].id+"')\">删除服务信息</span>";
					text += "</td>";
					text += "</tr>";
				}
				$("#productInfo").empty().append(text);
			}
		}
	});
}

function delProduct(id) {
	if(confirm("确认删除商品吗？")){
		$.ajax({
			type : "post",
			url : "/computer/ProductAction?type=del",
			data : {
				id : id
			},
			async : true,
			dataType : "text",
			error : function(request) {
				alert("网络请求错误，请重试！");
			},
			success : function(data) {
				if (data == "ok") {
					alert("商品已删除！");
					loadBusinessProduct();
				}else{
					alert("商品删除失败！请重试！");
				}
			}
		});
	}else{
		
	}
}

function openModal(a){
	$("#id").val($(a).parent().parent().children().eq(0).text());
	$("#title").val($(a).parent().parent().children().eq(1).text());
	$("#price").val($(a).parent().parent().children().eq(2).text());
	$("#simple").val($(a).parent().parent().children().eq(3).text());
	$("#userule").val($(a).parent().parent().children().eq(4).text());
	$("#myModal").modal('show');
	//$("#id").val(id);
}

function modifyProduct(){
	if($("#title").val() == null || $("#title").val() == ""){
		$("#err").empty().append("服务名称不能为空！");
		return false;
	}
	if($("#price").val() == null || $("#price").val() == ""){
		$("#err").empty().append("服务价格不能为空！");
		return false;
	}
	if($("#simple").val() == null || $("#simple").val() == ""){
		$("#err").empty().append("简介不能为空！");
		return false;
	}
	if($("#userule").val() == null || $("#userule").val() == ""){
		$("#err").empty().append("使用规则不能为空！");
		return false;
	}
	
	$.ajax({
		type : "post",
		url : "/computer/ProductAction?type=modify",
		data : $("#productItem").serialize(),
		async : true,
		dataType : "text",
		error : function(request) {
			alert("网络请求错误，请重试！");
		},
		success : function(data) {
			if (data == "ok") {
				alert("商品信息修改成功！");
				loadBusinessProduct();
			}else{
				alert("商品信息修改失败！请重试！");
			}
		}
	});
}

var businessId;
$(function() {
	businessId = $("#businessid").val();
	if (businessId == null || businessId == "") {
		location.href = "/computer/business/login.jsp";
		return false;
	}
	
});

function addService(){
	if($("#title").val() == null || $("#title").val() == ""){
		$("#err").empty().append("服务名称不能为空！");
		return false;
	}
	if($("#price").val() == null || $("#price").val() == ""){
		$("#err").empty().append("服务价格不能为空！");
		return false;
	}
	if($("#simple").val() == null || $("#simple").val() == ""){
		$("#err").empty().append("简介不能为空！");
		return false;
	}
	if($("#userule").val() == null || $("#userule").val() == ""){
		$("#err").empty().append("使用规则不能为空！");
		return false;
	}
	
	$.ajax({
		type: "post",
		url: "/computer/ProductAction?type=add",
		data: $("#productInfo").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok") {
				alert("服务发布成功！");
				location.reload();
			} else {
				$("#err").empty().append("服务发布失败，请重试！");
			}
		}
	});
	
	
}

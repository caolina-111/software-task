$(function() {
	

});

function login(){
	if($("#username").val() == null || $("#username").val() == ""){
		$("#err").empty().append("用户名不能为空！");
		return false;
	}
	if($("#password").val() == null || $("#password").val() == ""){
		$("#err").empty().append("密码不能为空！");
		return false;
	}
	$.ajax({
		type: "post",
		url: "/computer/BusinessAction?type=login",
		data: $("#user_login").serialize(),
		async: true,
		dataType: "text",
		error: function(request) {
			alert("网络请求错误，请重试！");
		},
		success: function(data) {
			if(data == "ok") {
				location.href = "/computer/business/index.jsp";
			} else {
				$("#err").empty().append("用户名密码错误，或您的账号正在审核中！");
			}
		}
	});
	
	
}
